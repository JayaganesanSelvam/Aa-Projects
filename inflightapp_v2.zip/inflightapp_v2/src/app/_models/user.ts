﻿export class User {
    id: number;
    email: string;
    username: string;
    phoneNumber: number;
    password: string;
    token: string;
}
