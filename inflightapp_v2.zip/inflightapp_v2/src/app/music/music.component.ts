import { Component, OnInit } from '@angular/core';
import { MusicService } from './music.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-music',
  templateUrl: './music.component.html',
  styleUrls: ['./music.component.css']
})

export class MusicComponent implements OnInit {
  musicList: any[];
  searchText;
  selectedMusic: any;
  updatedMusicName: string;
  updatedTags: string;
  updatedArtists: string;
  index: number;
  constructor(private musicService: MusicService) {}

  ngOnInit() {
    // this.getMusicList();
    this.musicList = [
      { Id: '1001', tags: 'Romantic, Soul', musicName: 'Adventure', thumbnailUrl: 'assets/images/games.jpg'},
      { Id: '1002', tags: 'Romantic, Soul', musicName: 'Action', thumbnailUrl: 'assets/images/movies.jpg'},
      { Id: '1003', tags: 'Romantic, Soul', musicName: 'Captain America', thumbnailUrl: 'assets/images/Penguins.jpg'},
      { Id: '1004', tags: 'Romantic, Soul', musicName: 'Avengers: The End Game', thumbnailUrl: 'assets/images/Tulips.jpg'},
      { Id: '1005', tags: 'Romantic, Soul', musicName: 'Guardians of the galaxy', thumbnailUrl: 'assets/images/games.jpg'},
      { Id: '1006', tags: 'Romantic, Soul', musicName: 'The sky is pink', thumbnailUrl: 'assets/images/movies.jpg'},
      { Id: '1007', tags: 'Romantic, Soul', musicName: 'Adventure', thumbnailUrl: 'assets/images/games.jpg'},
      { Id: '1008', tags: 'Romantic, Soul', musicName: 'Action', thumbnailUrl: 'assets/images/movies.jpg'}
    ];
    this.selectedMusic = this.musicList[0];
  }

  getMusicList(): void {
    this.musicService.getMusicList()
            .subscribe(data => {
                this.musicList = data['Items'].map(x => {
                  return {
                    musicName: x.Name,
                    Id: x.Id,
                    tags: 'Romantic, Soul',
                    thumbnailUrl: 'http://192.168.1.6:8096/emby/Items/' + x.Id + '/Images/Primary?maxHeight=324&tag='
                    + x.ImageTags.Primary + 'quality=90'
                  };
                });
            });
  }

  edit(musicId): void {
    console.log(musicId);
    this.selectedMusic = this.musicList[musicId];
    this.updatedTags = this.selectedMusic.tags;
    this.updatedMusicName = this.selectedMusic.musicName;
    this.index = musicId;
  }

  updateShow(musicId): void {
    this.musicList[musicId].enabled = !this.musicList[musicId].enabled;
  }

  submitUpdateForm(e): void {
    e.preventDefault();
    this.musicList[this.index].musicName = this.updatedMusicName;
    this.musicList[this.index].tags = this.updatedTags;
  }
}

