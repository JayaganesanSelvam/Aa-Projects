import { Component, OnInit, ViewChild } from '@angular/core';
import { MoviesService } from './movies.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-movies',
  templateUrl: './movies.component.html',
  styleUrls: ['./movies.component.css']
})
export class MoviesComponent implements OnInit {
  moviesList: any[];
  searchText;
  selectedMovie: any;
  updatedMovieName: string;
  updatedTags: string;
  updatedCast: string;
  index: string;
  constructor(private moviesService: MoviesService) {}

  ngOnInit() {
    // this.getMoviesList();
    this.moviesList = [
      { Id: '1001', tags: 'Crime Thriller Drama', movieName: 'Adventure', thumbnailUrl: 'assets/images/games.jpg'},
      { Id: '1002', tags: 'Crime Thriller Drama', movieName: 'Action', thumbnailUrl: 'assets/images/movies.jpg'},
      { Id: '1003', tags: 'Crime Thriller Drama', movieName: 'Captain America', thumbnailUrl: 'assets/images/Penguins.jpg'},
      { Id: '1004', tags: 'Crime Thriller Drama', movieName: 'Avengers: The End Game', thumbnailUrl: 'assets/images/Tulips.jpg'},
      { Id: '1005', tags: 'Crime Thriller Drama', movieName: 'Guardians of the galaxy', thumbnailUrl: 'assets/images/games.jpg'},
      { Id: '1006', tags: 'Crime Thriller Drama', movieName: 'The sky is pink', thumbnailUrl: 'assets/images/movies.jpg'},
      { Id: '1007', tags: 'Crime Thriller Drama', movieName: 'Adventure', thumbnailUrl: 'assets/images/games.jpg'},
      { Id: '1008', tags: 'Crime Thriller Drama', movieName: 'Action', thumbnailUrl: 'assets/images/movies.jpg'}
    ];
    this.selectedMovie = this.moviesList[0];
  }

  getMoviesList(): void {
    this.moviesService.getMoviesList()
            .subscribe(data => {
                this.moviesList = data['Items'].map(x => {
                  return {
                    movieName: x.Name,
                    Id: x.Id,
                    thumbnailUrl: 'http://192.168.1.6:8096/emby/Items/' + x.Id + '/Images/Primary?maxHeight=324&tag='
                    + x.ImageTags.Primary + 'quality=90',
                    tags: 'crime thriller drama'
                  };
                });
            });
  }

  edit(movieId): void {
    console.log(movieId);
    this.selectedMovie = this.moviesList[movieId];
    this.updatedTags = this.selectedMovie.tags;
    this.updatedMovieName = this.selectedMovie.movieName;
    this.index = movieId;
  }

  updateShow(movieId): void {

   // this.disabledMovies.push(this.moviesList[movieId].movieName);
    this.moviesList[movieId].enabled = !this.moviesList[movieId].enabled;
    // console.log(this.disabledMovies)
  }

  // addShow(movieId): void {
  //   this.moviesList[movieId].enabled = !this.moviesList[movieId].enabled;
  //   const name = this.moviesList[movieId].movieName;
  //   let tempList = []
  //   tempList = this.disabledMovies.filter( a => a != name);
  //   this.moviesList = tempList;
  //   this.moviesList[movieId].enabled = !this.moviesList[movieId].enabled;
  //   console.log(this.disabledMovies)

  // }

  submitUpdateForm(e): void {
    console.log(this.updatedMovieName);
    console.log(this.moviesList[this.index].movieName);
    console.log(this.selectedMovie.Id);
    this.moviesList[this.index].movieName = this.updatedMovieName;
    this.moviesList[this.index].tags = this.updatedTags;
    this.moviesService.updateMovieDetails(this.selectedMovie.Id, this.updatedMovieName, this.updatedTags)
            .subscribe(data => {
                console.log(data);
                this.moviesList[this.index].movieName = this.updatedMovieName;
                  }
                );
  }
}
