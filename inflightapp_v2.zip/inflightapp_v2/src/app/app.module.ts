import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MoviesComponent } from './movies/movies.component';
import { HomeComponent } from './home/home.component';
import { UserProfileComponent } from './userProfile/userProfile.component';
import { MusicComponent } from './music/music.component';
import { PasswordComponent } from './password/password.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { UploadComponent } from './upload/upload.component';
import { MoviesService } from './movies/movies.service';
import { Ng2SearchPipeModule } from 'ng2-search-filter';

// used to create fake backend
import { fakeBackendProvider } from './_helpers';

import { AlertComponent } from './_directives';
import { AuthGuard } from './_guards';
import { JwtInterceptor, ErrorInterceptor } from './_helpers';
import { AlertService, AuthenticationService, UserService } from './_services';
import { SampleComponent } from './sample';
import { LoginComponent } from './login';
import { RegisterComponent } from './register';
import { MusicService } from './music/music.service';
import { UserProfileService } from './userProfile/userProfile.service';

@NgModule({
  declarations: [
    AppComponent,
    MoviesComponent,
    HomeComponent,
    UserProfileComponent,
    MusicComponent,
    PasswordComponent,
    PageNotFoundComponent,
    UploadComponent,
    SampleComponent,
    AlertComponent,
    LoginComponent,
    RegisterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    Ng2SearchPipeModule
  ],
  providers: [MoviesService,
    MusicService,
    UserProfileService,
    AuthGuard,
    AlertService,
    AuthenticationService,
    UserService,
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },

    // provider used to create fake backend
    fakeBackendProvider],
  bootstrap: [AppComponent]
})
export class AppModule { }
