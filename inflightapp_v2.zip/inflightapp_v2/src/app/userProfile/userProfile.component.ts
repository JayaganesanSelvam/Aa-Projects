import { Component, OnInit, OnDestroy } from '@angular/core';
import { User } from '../_models/user';
import { Subscription } from 'rxjs';
import { AuthenticationService } from '../_services/authentication.service';
import { AlertService } from '../_services';

@Component({
  selector: 'app-user-profile',
  templateUrl: './userProfile.component.html',
  styleUrls: ['./userProfile.component.css']
})
export class UserProfileComponent implements OnInit, OnDestroy {
  currentUser: User;
  currentUserSubscription: Subscription;
  updatedUserName: string;
  updatedPhoneNumber: number;


  constructor(
    private alertService: AlertService,
    private authenticationService: AuthenticationService
  ) {
    this.currentUserSubscription = this.authenticationService.currentUser.subscribe(
      user => {
        this.currentUser = user;
        if (user !== null) {
          this.updatedUserName = user.username;
          this.updatedPhoneNumber = user.phoneNumber;
        }
      }
    );
  }

  ngOnInit() {
}


  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.currentUserSubscription.unsubscribe();
  }

  updateUser() {
    const usersObject = JSON.parse(localStorage.getItem('users'));
    const user = JSON.parse(localStorage.getItem('currentUser'));
    this.authenticationService.updateUser({
      id: user.id,
      username: this.updatedUserName,
      email: user.email,
      phoneNumber: this.updatedPhoneNumber,
      token: user.token
    });
    for (const index in usersObject) {
      if (usersObject[index].email === this.currentUser.email) {
        usersObject[index].username = this.updatedUserName;
        usersObject[index].phoneNumber = this.updatedPhoneNumber;
      }
    }
    localStorage.setItem('users', JSON.stringify(usersObject));
  }
}
