import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { HttpErrorResponse } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UploadService {
  constructor(private http: HttpClient) {}

  uploadData(cat, tags, formData: FormData): Observable<any> {
    let headers = new HttpHeaders();
    headers = headers.set('Content-Type', 'application/json; charset=utf-8');
    headers = headers.set('enctype', 'multipart/form-data');
    return this.http
      .post(
        'http://192.168.1.6:8080/uploadVideo/?category=' +
          cat +
          '&tags=' +
          tags +
          '',
        formData
      )
      .pipe(tap(data => console.log('Data Fetched:' + JSON.stringify(data))));
  }

  refreshDB() {
    const headers = new HttpHeaders({ 'X-Emby-Token' : '3e3397ed0e474a0f8ed1077b60ddb5bb' });
    const options = { headers };

    return this.http.post('http://localhost:8096/emby/Library/Refresh', {}, options);
  }
  //   public getVideo(url:string): Observable<any> {
  //     const headers = new HttpHeaders({ 'Authorization': 'Bearer ' + this.authenticationService.token, 'Content-Type': 'video/mp4' });
  //     const options = { headers: headers };
  //     return this.http.get(url, options);
  // }

  //   private handleError(err:HttpErrorResponse) {
  //     let errMsg:string='';
  //     if (err.error instanceof Error) {
  //        // A client-side or network error occurred. Handle it accordingly.
  //        console.log('An error occurred:', err.error.message);
  //         errMsg=err.error.message;}
  //        else {
  //        // The backend returned an unsuccessful response code.
  //        // The response body may contain clues as to what went wrong,
  //        console.log(`Backend returned code ${err.status}`);
  //           errMsg=err.error.status;
  //      }
  //         return throwError(errMsg);
  //   }
}
