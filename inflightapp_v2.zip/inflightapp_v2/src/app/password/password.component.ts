import { Component, OnInit, OnDestroy } from '@angular/core';
import { AlertService } from '../_services/alert.service';
import { AuthenticationService } from '../_services/authentication.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MustMatch } from '../_helpers/must-match.validator';
import { User } from '../_models';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-password',
  templateUrl: './password.component.html',
  styleUrls: ['./password.component.css']
})
export class PasswordComponent implements OnInit, OnDestroy {
  currentUser: User;
  currentUserSubscription: Subscription;
  passwordForm: FormGroup;
  loading = false;
  submitted = false;

  constructor(
    private formBuilder: FormBuilder,
    private alertService: AlertService,
    private router: Router,
    private authenticationService: AuthenticationService
  ) { this.currentUserSubscription = this.authenticationService.currentUser.subscribe(
    user => {
      this.currentUser = user;
    }
  ); }

  ngOnInit() {
    this.passwordForm = this.formBuilder.group({
        oldPassword: ['', Validators.required],
        confirmPassword: ['', Validators.required],
        newPassword: ['', [Validators.required, Validators.minLength(6)]]
    }, {
      validator: MustMatch('newPassword', 'confirmPassword')
  });
}

ngOnDestroy() {
  // unsubscribe to ensure no memory leaks
  this.currentUserSubscription.unsubscribe();
}

// convenience getter for easy access to form fields
get f() { return this.passwordForm.controls; }

  updatePassword() {
    this.submitted = true;

        // stop here if form is invalid
    if (this.passwordForm.invalid) {
            return;
        }

    this.loading = true;
    const usersObject = JSON.parse(localStorage.getItem('users'));
    for (const index in usersObject) {
      if (usersObject[index].email === this.currentUser.email) {
        if (usersObject[index].password === this.f.oldPassword.value) {
          usersObject[index].password = this.f.newPassword.value;
          localStorage.setItem('users', JSON.stringify(usersObject));
          this.alertService.success('Password changed successfully', true);
          this.router.navigate(['/userProfile']);
        } else {
          this.alertService.error('Please enter correct password');
          this.loading = false;
        }
      }
    }
  }

  onReset() {
        this.submitted = false;
        this.loading = false;
        this.passwordForm.reset();
    }

}
